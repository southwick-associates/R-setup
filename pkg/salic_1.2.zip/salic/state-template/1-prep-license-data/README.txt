
Dan Note from Apr 2019:

These Rmd templates are the older extremely verbose versions. Chelsea has
since created her own templates for this step.

The county appending step should also be included in the script sequence.
See add_county_fips.R included here as an example.

