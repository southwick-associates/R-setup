This project was setup using package 'salic'

Certain files shouldn't be edited by hand:
- .Rprofile             specifies R version and project library
- snapshot-library.csv  details project-specific packages (if they exist)

Folder Structure:
- 1-prep-license-data
- 2-license-history
- 3-secondary-data
- 4-dashboard-results

- data (input data to analysis)
- out (for output data/results)
